<!-- ========================================
  BOTTOM STYLE 6
 ========================================-->

<div class="menu_post_header">
	<div class="container">
		<!-- Menu Primary Full  alignright - alignleft textaligncenter  -->
		<nav class="nav-ilgelo-main textaligncenter">
			<?php wp_nav_menu(array(
				'container' => 'ul',
				'container_id'    => 'ig_menu',
				'menu_class'      => 'main-menu',
				'theme_location' => 'central_menu',
				'depth'           => 4,
				'fallback_cb'=> ''

				)
			);
			?>
		</nav>
	</div> <!-- menu_post_header -->
</div> <!-- Container -->