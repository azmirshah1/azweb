
<!-- ========================================
 TOP STYLE 6
 ========================================-->

<header class="header">
	<div class="container">
		
		<!-- Menu Primary Full  alignright - alignleft textaligncenter  -->
		<nav class="nav-ilgelo-main journey-menu textaligncenter">
		<?php wp_nav_menu(array(
		      'container' => 'ul',
		      'container_id'    => 'ig_menu',
			 'menu_class'      => 'main-menu',
		      'theme_location' => 'top_menu',
		      'depth'           => 4,
		      'fallback_cb'=> ''

		      )
		   );
		?>
		</nav>

	</div><!-- end .container -->
</header>