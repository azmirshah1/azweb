
<!-- ========================================
 TOP STYLE 3
 ========================================-->

<header class="header">
	<div class="container">

		<div class="ig-top-social textaligncenter ">
			<?php  include(TEMPLATEPATH."/template/social-icons-menu.php"); ?>
		</div><!-- END SOCIAL NAVIGATION -->

	</div><!-- end .container -->
</header>