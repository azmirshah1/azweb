<!-- ========================================
     Color Background
========================================-->

<div class="semple_header">
	<div class="bg-logo-container" style="background-color: <?php echo esc_attr($ilgelo_options['ilgelo-bg-logo']) ?>;">
          <?php  include(TEMPLATEPATH."/template/header/header-logo.php"); ?>
	</div><!-- end bg-logo-container -->
</div><!-- end semple_header -->