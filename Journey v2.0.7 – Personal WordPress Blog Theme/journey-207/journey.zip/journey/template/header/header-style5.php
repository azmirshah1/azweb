<!-- ========================================
     Responsive Image Background
========================================-->


<img class="img_full_responsive" src="<?php echo  $ilgelo_options['ilgelo-responsive-image-bg']['url'];?>">





