<!-- ========================================
  BOTTOM STYLE 4
 ========================================-->

<div class="menu_post_header">
	<div class="container">

		<!-- SOCIAL NAVIGATION  ig-top-social-right - ig-top-social-left - textaligncenter -->
		<div class="ig-top-social textaligncenter ">
			<?php  include(TEMPLATEPATH."/template/social-icons-menu.php"); ?>
		</div>
		<!-- END SOCIAL NAVIGATION -->

	</div> <!-- menu_post_header -->
</div> <!-- Container -->