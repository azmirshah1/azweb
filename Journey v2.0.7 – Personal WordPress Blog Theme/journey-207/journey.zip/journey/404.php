<?php get_header(); ?>
<div class="container big_padding container_up">
   <div class="row">
		<h2 class="textaligncenter">ERROR 404</h3>
		<h4 class="textaligncenter">
		<?php _e(' The page you are looking for might have been removed, had its name changed or is temporarily unavailable', 'ilgelo') ?>	            
		</h4>
   </div><!-- end row -->
</div> 
<?php get_footer(); ?>